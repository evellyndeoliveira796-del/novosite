document.addEventListener('DOMContentLoaded', async () => {
  const $ = id => document.getElementById(id);
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
  const money = value => Number(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  let appointments = [];
  let services = [];

  async function api(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      headers: { Accept: 'application/json', 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '', ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) }
    });
    if (response.status === 204) return null;
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.mensagem || `Falha na solicitação (HTTP ${response.status}).`);
    return body;
  }

  const setState = (id, text, error = false) => {
    const node = $(id);
    node.textContent = text;
    node.className = error ? 'notice error' : 'small';
  };
  const emptyRow = (columns, text) => `<tr><td class="empty-state" colspan="${columns}">${escapeHtml(text)}</td></tr>`;
  const formattedDate = value => {
    if (Array.isArray(value)) return `${String(value[2]).padStart(2, '0')}/${String(value[1]).padStart(2, '0')}/${value[0]}`;
    if (!value) return '—';
    const parts = String(value).split('-');
    return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : escapeHtml(value);
  };
  const formattedTime = value => {
    if (Array.isArray(value)) return `${String(value[0]).padStart(2, '0')}:${String(value[1]).padStart(2, '0')}`;
    return value ? escapeHtml(String(value).slice(0, 5)) : '—';
  };
  const formattedDateTime = value => {
    if (Array.isArray(value)) {
      const [y, m, d, h = 0, min = 0, sec = 0] = value;
      return `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y} ${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
    }
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? escapeHtml(value) : date.toLocaleString('pt-BR');
  };

  try {
    const currentUser = await api('/login/sessao');
    if (currentUser.perfil !== 'ADMIN') {
      window.location.replace('/usuario');
      return;
    }
    $('adminBoasVindas').textContent = `Olá, ${currentUser.nome}. Acompanhe a operação e as ações registradas.`;
  } catch {
    window.location.replace('/login');
    return;
  }

  document.querySelectorAll('.tab-button').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('.tab-button').forEach(item => item.classList.toggle('active', item === button));
    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.toggle('active', panel.id === button.dataset.panel));
  }));

  function renderAppointments() {
    const filter = $('filtroStatus').value;
    const visible = filter === 'TODOS' ? appointments : appointments.filter(item => item.status === filter);
    const counts = {
      total: appointments.length,
      pendente: appointments.filter(item => item.status === 'PENDENTE').length,
      confirmado: appointments.filter(item => item.status === 'CONFIRMADO').length,
      cancelado: appointments.filter(item => item.status === 'CANCELADO').length
    };
    $('resumoAgenda').innerHTML = [
      ['Total', counts.total], ['Pendentes', counts.pendente], ['Confirmados', counts.confirmado], ['Cancelados', counts.cancelado]
    ].map(([label, value]) => `<article class="summary-card"><span>${label}</span><strong>${value}</strong></article>`).join('');

    $('agendaCorpo').innerHTML = visible.length ? visible.map(item => {
      let actions = '';
      if (item.status === 'PENDENTE') actions = `<button class="button primary" data-action="status" data-id="${Number(item.id)}" data-status="CONFIRMADO">Confirmar</button><button class="button danger" data-action="status" data-id="${Number(item.id)}" data-status="CANCELADO">Cancelar</button>`;
      else if (item.status === 'CONFIRMADO') actions = `<button class="button danger" data-action="status" data-id="${Number(item.id)}" data-status="CANCELADO">Cancelar</button>`;
      else actions = '<span class="small">Sem ações</span>';
      return `<tr>
        <td>${Number(item.id)}</td><td>${escapeHtml(item.nomeCliente)}</td><td>${escapeHtml(item.servico)}</td>
        <td>${formattedDate(item.data)}</td><td>${formattedTime(item.hora)}</td>
        <td><span class="status ${escapeHtml(item.status)}">${escapeHtml(item.status)}</span></td>
        <td><div class="row-actions">${actions}</div></td>
      </tr>`;
    }).join('') : emptyRow(7, appointments.length ? 'Nenhum agendamento para este filtro.' : 'Nenhum agendamento cadastrado.');
    setState('agendaEstado', `${visible.length} agendamento(s) exibido(s).`);
  }

  async function loadAppointments() {
    try {
      appointments = await api('/admin/agendamentos');
      renderAppointments();
    } catch (error) { setState('agendaEstado', error.message, true); }
  }

  function renderServices() {
    $('servicosCorpo').innerHTML = services.length ? services.map(service => `
      <tr><td>${escapeHtml(service.nome)}</td><td>${service.tipo === 'BARBA' ? 'Barba' : 'Corte'}</td>
      <td>${Number(service.duracaoMinutos)} min</td><td>${money(service.preco)}</td>
      <td><div class="row-actions"><button class="button secondary" data-action="edit-service" data-id="${Number(service.id)}">Editar</button>
      <button class="button danger" data-action="delete-service" data-id="${Number(service.id)}">Excluir</button></div></td></tr>`).join('') : emptyRow(5, 'Nenhum serviço cadastrado. Use o formulário acima.');
  }

  async function loadServices() {
    try { services = await api('/servico'); renderServices(); }
    catch (error) { setState('servicoMensagem', error.message, true); }
  }

  async function loadUsers() {
    setState('usuariosEstado', 'Carregando usuários…');
    try {
      const users = await api('/usuario/lista');
      $('usuariosCorpo').innerHTML = users.length ? users.map(user => `<tr><td>${escapeHtml(user.nome)}</td><td>${escapeHtml(user.email)}</td><td>${user.perfil === 'ADMIN' ? 'Barbeiro / administrador' : 'Cliente'}</td></tr>`).join('') : emptyRow(3, 'Nenhum usuário cadastrado.');
      setState('usuariosEstado', `${users.length} usuário(s).`);
    } catch (error) { $('usuariosCorpo').innerHTML = ''; setState('usuariosEstado', error.message, true); }
  }

  async function loadAudit() {
    setState('auditoriaEstado', 'Carregando histórico…');
    try {
      const entries = await api('/admin/logs');
      $('auditoriaCorpo').innerHTML = entries.length ? entries.map(entry => `<tr><td>${formattedDateTime(entry.dataHora)}</td><td>${escapeHtml(entry.usuarioExecutor || 'anônimo')}</td><td>${escapeHtml(entry.acao)}</td></tr>`).join('') : emptyRow(3, 'Ainda não há eventos registrados.');
      setState('auditoriaEstado', `${entries.length} evento(s) recentes.`);
    } catch (error) { $('auditoriaCorpo').innerHTML = ''; setState('auditoriaEstado', error.message, true); }
  }

  $('filtroStatus').addEventListener('change', renderAppointments);
  $('atualizarAgenda').addEventListener('click', loadAppointments);
  $('atualizarUsuarios').addEventListener('click', loadUsers);
  $('atualizarAuditoria').addEventListener('click', loadAudit);

  $('agendaCorpo').addEventListener('click', async event => {
    const button = event.target.closest('[data-action="status"]');
    if (!button) return;
    button.disabled = true;
    try {
      await api(`/admin/agendamentos/${Number(button.dataset.id)}/status?status=${encodeURIComponent(button.dataset.status)}`, { method: 'PUT' });
      setState('agendaEstado', 'Status atualizado e registrado na auditoria.');
      await loadAppointments();
      await loadAudit();
    } catch (error) { setState('agendaEstado', error.message, true); button.disabled = false; }
  });

  function resetServiceForm() {
    $('formServico').reset();
    $('servicoId').value = '';
    $('salvarServico').textContent = 'Cadastrar serviço';
  }
  $('limparServico').addEventListener('click', resetServiceForm);
  $('formServico').addEventListener('submit', async event => {
    event.preventDefault();
    if (!event.currentTarget.reportValidity()) return;
    const id = $('servicoId').value;
    const body = {
      nome: $('servicoNome').value.trim(), tipo: $('servicoTipo').value,
      duracaoMinutos: Number($('servicoDuracao').value), preco: Number($('servicoPreco').value)
    };
    try {
      await api(id ? `/servico/${Number(id)}` : '/servico', { method: id ? 'PUT' : 'POST', body: JSON.stringify(body) });
      setState('servicoMensagem', id ? 'Serviço atualizado.' : 'Serviço cadastrado.');
      resetServiceForm();
      await loadServices();
      await loadAudit();
    } catch (error) { setState('servicoMensagem', error.message, true); }
  });

  $('servicosCorpo').addEventListener('click', async event => {
    const edit = event.target.closest('[data-action="edit-service"]');
    const remove = event.target.closest('[data-action="delete-service"]');
    if (edit) {
      const service = services.find(item => item.id === Number(edit.dataset.id));
      if (!service) return;
      $('servicoId').value = service.id;
      $('servicoNome').value = service.nome;
      $('servicoTipo').value = service.tipo;
      $('servicoDuracao').value = service.duracaoMinutos;
      $('servicoPreco').value = service.preco;
      $('salvarServico').textContent = 'Salvar alterações';
      $('servicoNome').focus();
    }
    if (remove && window.confirm('Deseja excluir este serviço? O sistema impedirá a exclusão se houver agendamentos vinculados.')) {
      try {
        await api(`/servico/${Number(remove.dataset.id)}`, { method: 'DELETE' });
        setState('servicoMensagem', 'Serviço excluído.');
        await loadServices();
        await loadAudit();
      } catch (error) { setState('servicoMensagem', error.message, true); }
    }
  });

  $('formBarbeiro').addEventListener('submit', async event => {
    event.preventDefault();
    if (!event.currentTarget.reportValidity()) return;
    try {
      await api('/usuario/administradores', { method: 'POST', body: JSON.stringify({
        nome: $('barbeiroNome').value.trim(), email: $('barbeiroEmail').value.trim(), senha: $('barbeiroSenha').value
      }) });
      event.currentTarget.reset();
      setState('equipeMensagem', 'Conta administrativa criada.');
      await loadUsers();
      await loadAudit();
    } catch (error) { setState('equipeMensagem', error.message, true); }
  });

  $('sair').addEventListener('click', async () => {
    await fetch('/login/logout', { method: 'POST', headers: { 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '' } }).catch(() => {});
    sessionStorage.clear();
    window.location.assign('/login');
  });

  await Promise.all([loadAppointments(), loadServices(), loadUsers(), loadAudit()]);
});
