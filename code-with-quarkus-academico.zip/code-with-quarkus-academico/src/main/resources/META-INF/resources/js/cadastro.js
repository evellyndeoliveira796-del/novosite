document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('formCadastro');
  const message = document.getElementById('cadastroMensagem');
  form.addEventListener('submit', async event => {
    event.preventDefault();
    message.className = 'notice';
    message.textContent = 'Criando sua conta…';
    const body = {
      nome: document.getElementById('cadNome').value.trim(),
      email: document.getElementById('cadEmail').value.trim(),
      senha: document.getElementById('cadSenha').value
    };
    try {
      const response = await fetch('/cadastro', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.mensagem || 'Não foi possível concluir o cadastro.');
      message.className = 'notice success';
      message.textContent = 'Conta criada. Redirecionando para o login…';
      setTimeout(() => window.location.assign('/login'), 900);
    } catch (error) {
      message.className = 'notice error';
      message.textContent = error.message || 'Erro de conexão com o servidor.';
    }
  });
});
