document.addEventListener('DOMContentLoaded', async () => {
  const select = document.getElementById('servico');
  const form = document.getElementById('formAgendamento');
  const message = document.getElementById('agendamentoMensagem');
  const name = document.getElementById('nomeAutenticado');
  const date = document.getElementById('data');
  date.min = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

  const setMessage = (text, error = false) => {
    message.textContent = text;
    message.className = `notice${error ? ' error' : ''}`;
  };
  const readError = async response => {
    const body = await response.json().catch(() => ({}));
    return body.mensagem || `Não foi possível concluir (HTTP ${response.status}).`;
  };

  try {
    const usuarioId = sessionStorage.getItem('usuarioId');
    const headers = { Accept: 'application/json', 'X-Usuario-Id': usuarioId || '' };
    const session = await fetch('/login/sessao', { headers });
    if (!session.ok) { window.location.replace('/login'); return; }
    const user = await session.json();
    name.textContent = user.nome;

    const response = await fetch('/servico', { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('Não foi possível carregar os serviços.');
    const services = await response.json();
    select.replaceChildren(new Option('Selecione um serviço', ''));
    services.forEach(service => {
      const price = Number(service.preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      select.add(new Option(`${service.nome} — ${price}`, String(service.id)));
    });
    if (!services.length) select.add(new Option('Nenhum serviço cadastrado', ''));
  } catch (error) {
    select.replaceChildren(new Option('Erro ao carregar serviços', ''));
    setMessage(error.message || 'Erro de conexão com o servidor.', true);
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const button = document.getElementById('botaoAgendar');
    button.disabled = true;
    setMessage('Registrando agendamento…');
    try {
      const response = await fetch('/agendar/agendamento', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '' },
        body: JSON.stringify({
          data: date.value,
          hora: document.getElementById('hora').value,
          servico: select.value
        })
      });
      if (!response.ok) throw new Error(await readError(response));
      const booking = await response.json();
      setMessage(`Agendamento #${booking.id} criado em nome de ${booking.nomeCliente}. Consulte seu perfil para acompanhar o status.`);
      form.reset();
      date.min = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    } catch (error) {
      setMessage(error.message || 'Erro de conexão com o servidor.', true);
    } finally {
      button.disabled = false;
    }
  });
});
