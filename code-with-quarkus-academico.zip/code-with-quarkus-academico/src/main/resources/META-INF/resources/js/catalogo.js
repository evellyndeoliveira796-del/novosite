document.addEventListener('DOMContentLoaded', () => {
  const list = document.getElementById('catalogoLista');
  const state = document.getElementById('catalogoEstado');
  const buttons = [...document.querySelectorAll('[data-filter]')];
  let services = [];
  let filter = 'TODOS';

  const money = value => Number(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const safe = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));

  function render() {
    const filtered = filter === 'TODOS' ? services : services.filter(item => item.tipo === filter);
    list.innerHTML = '';
    if (!filtered.length) {
      state.textContent = services.length ? 'Nenhum serviço nesta categoria.' : 'Nenhum serviço cadastrado no momento.';
      state.hidden = false;
      return;
    }
    state.hidden = true;
    list.innerHTML = filtered.map(item => `
      <article class="service-card">
        <span class="service-type">${item.tipo === 'BARBA' ? 'Barba' : 'Corte'}</span>
        <h2>${safe(item.nome)}</h2>
        <p class="service-meta">${Number(item.duracaoMinutos)} min</p>
        <p class="service-price">${money(item.preco)}</p>
      </article>`).join('');
  }

  buttons.forEach(button => button.addEventListener('click', () => {
    buttons.forEach(item => item.classList.toggle('active', item === button));
    filter = button.dataset.filter;
    render();
  }));

  fetch('/servico')
    .then(response => {
      if (!response.ok) throw new Error('Falha ao consultar o catálogo.');
      return response.json();
    })
    .then(data => { services = Array.isArray(data) ? data : []; render(); })
    .catch(() => {
      state.textContent = 'Não foi possível carregar os serviços. Atualize a página para tentar novamente.';
      state.hidden = false;
    });
});
