document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('formLogin');
  const message = document.getElementById('loginMensagem');
  form.addEventListener('submit', async event => {
    event.preventDefault();
    message.className = 'notice';
    message.textContent = 'Validando acesso…';
    try {
      const response = await fetch('/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          email: document.getElementById('email').value.trim(),
          senha: document.getElementById('senha').value
        })
      });
      const usuario = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(usuario.mensagem || 'E-mail ou senha inválidos.');
      sessionStorage.setItem('usuarioId', String(usuario.id));
      sessionStorage.setItem('usuario', JSON.stringify(usuario));
      window.location.assign(usuario.perfil === 'ADMIN' ? '/admin' : '/agendar');
    } catch (error) {
      message.className = 'notice error';
      message.textContent = error.message || 'Não foi possível conectar ao servidor.';
    }
  });
});
