document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('formAdminInicial');
  const message = document.getElementById('adminInicialMensagem');
  form.addEventListener('submit', async event => {
    event.preventDefault();
    message.className = 'notice';
    message.textContent = 'Validando configuração inicial…';
    const body = {
      nome: document.getElementById('adminNome').value.trim(),
      email: document.getElementById('adminEmail').value.trim(),
      senha: document.getElementById('adminSenha').value,
      tokenInicial: document.getElementById('tokenInicial').value
    };
    try {
      const response = await fetch('/cadastro/admin-inicial', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.mensagem || 'Não foi possível concluir a configuração.');
      message.className = 'notice success';
      message.textContent = 'Administrador criado. Entre com as credenciais cadastradas.';
      form.reset();
    } catch (error) {
      message.className = 'notice error';
      message.textContent = error.message || 'Erro de conexão com o servidor.';
    }
  });
});
