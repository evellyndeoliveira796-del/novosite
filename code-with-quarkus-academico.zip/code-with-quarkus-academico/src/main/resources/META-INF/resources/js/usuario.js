document.addEventListener('DOMContentLoaded', async () => {
  const profileMessage = document.getElementById('perfilMensagem');
  const historyMessage = document.getElementById('historicoEstado');
  const history = document.getElementById('historicoAgendamentos');
  const safe = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
  const showError = async response => {
    const data = await response.json().catch(() => ({}));
    return data.mensagem || `Solicitação inválida (HTTP ${response.status}).`;
  };

  let user;
  try {
    const response = await fetch('/usuario/me', { headers: { Accept: 'application/json', 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '' } });
    if (!response.ok) { window.location.replace('/login'); return; }
    user = await response.json();
    document.getElementById('perfilNome').value = user.nome;
    document.getElementById('perfilEmail').value = user.email;
    document.getElementById('linkAdmin').classList.toggle('hidden', user.perfil !== 'ADMIN');
  } catch {
    window.location.replace('/login');
    return;
  }

  document.getElementById('formPerfil').addEventListener('submit', async event => {
    event.preventDefault();
    profileMessage.className = 'notice';
    profileMessage.textContent = 'Salvando alterações…';
    const body = {
      nome: document.getElementById('perfilNome').value.trim(),
      email: document.getElementById('perfilEmail').value.trim(),
      senhaAtual: document.getElementById('senhaAtual').value,
      novaSenha: document.getElementById('novaSenha').value || null
    };
    try {
      const response = await fetch('/usuario/me', {
        method: 'PUT', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '' },
        body: JSON.stringify(body)
      });
      const updated = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(updated.mensagem || await showError(response));
      user = updated;
      document.getElementById('perfilNome').value = user.nome;
      document.getElementById('perfilEmail').value = user.email;
      document.getElementById('senhaAtual').value = '';
      document.getElementById('novaSenha').value = '';
      profileMessage.className = 'notice success';
      profileMessage.textContent = 'Perfil atualizado com sucesso.';
    } catch (error) {
      profileMessage.className = 'notice error';
      profileMessage.textContent = error.message || 'Erro de conexão com o servidor.';
    }
  });

  try {
    const response = await fetch('/agendar/meus', { headers: { Accept: 'application/json', 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '' } });
    if (!response.ok) throw new Error(await showError(response));
    const bookings = await response.json();
    history.replaceChildren();
    if (!bookings.length) {
      historyMessage.textContent = 'Você ainda não possui agendamentos.';
      return;
    }
    historyMessage.textContent = '';
    history.innerHTML = bookings.map(item => `
      <article class="service-card">
        <span class="service-type">Agendamento #${Number(item.id)}</span>
        <h3>${safe(item.servico)}</h3>
        <p class="service-meta">${safe(item.data)} às ${safe(String(item.hora).slice(0, 5))}</p>
        <p><span class="status ${safe(item.status)}">${safe(item.status)}</span></p>
      </article>`).join('');
  } catch (error) {
    historyMessage.className = 'notice error';
    historyMessage.textContent = error.message || 'Não foi possível carregar os agendamentos.';
  }

  document.getElementById('sair').addEventListener('click', async () => {
    await fetch('/login/logout', { method: 'POST', headers: { 'X-Usuario-Id': sessionStorage.getItem('usuarioId') || '' } }).catch(() => {});
    sessionStorage.clear();
    window.location.assign('/login');
  });
});
