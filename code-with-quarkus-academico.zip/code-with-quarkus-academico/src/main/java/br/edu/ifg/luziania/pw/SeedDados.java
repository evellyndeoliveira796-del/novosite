package br.edu.ifg.luziania.pw;

import br.edu.ifg.luziania.pw.model.dao.ServicoDAO;
import br.edu.ifg.luziania.pw.model.entity.Servico;
import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.math.BigDecimal;

@ApplicationScoped
public class SeedDados {
  @Inject ServicoDAO servicoDAO;

  @Transactional
  void aoIniciar(@Observes StartupEvent event) {
    if (!servicoDAO.listarTodos().isEmpty()) return;

    servicoDAO.salvar(new Servico("Corte na Máquina", "CORTE", 20, new BigDecimal("25.00")));
    servicoDAO.salvar(new Servico("Pézinho", "CORTE", 10, new BigDecimal("15.00")));
    servicoDAO.salvar(new Servico("Corte Social", "CORTE", 30, new BigDecimal("35.00")));
    servicoDAO.salvar(new Servico("Corte Degradê", "CORTE", 40, new BigDecimal("45.00")));
    servicoDAO.salvar(new Servico("Combo Corte + Barba", "CORTE", 60, new BigDecimal("65.00")));
    servicoDAO.salvar(new Servico("Sobrancelha na Navalha", "BARBA", 15, new BigDecimal("15.00")));
    servicoDAO.salvar(new Servico("Barba Tradicional", "BARBA", 25, new BigDecimal("30.00")));
    servicoDAO.salvar(new Servico("Barboterapia", "BARBA", 35, new BigDecimal("40.00")));
  }
}
