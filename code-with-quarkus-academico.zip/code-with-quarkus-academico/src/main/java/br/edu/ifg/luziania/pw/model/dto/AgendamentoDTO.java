package br.edu.ifg.luziania.pw.model.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class AgendamentoDTO {
  private Integer id;
  private Integer clienteId;
  private String nomeCliente;
  private LocalDate data;
  private LocalTime hora;
  private String servico;
  private String status;

  public AgendamentoDTO() {}

  public AgendamentoDTO(Integer id, Integer clienteId, String nomeCliente, LocalDate data,
                        LocalTime hora, String servico, String status) {
    this.id = id;
    this.clienteId = clienteId;
    this.nomeCliente = nomeCliente;
    this.data = data;
    this.hora = hora;
    this.servico = servico;
    this.status = status;
  }

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public Integer getClienteId() { return clienteId; }
  public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }
  public String getNomeCliente() { return nomeCliente; }
  public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
  public LocalDate getData() { return data; }
  public void setData(LocalDate data) { this.data = data; }
  public LocalTime getHora() { return hora; }
  public void setHora(LocalTime hora) { this.hora = hora; }
  public String getServico() { return servico; }
  public void setServico(String servico) { this.servico = servico; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
}
