package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.dto.CadastroAdminInicialDTO;
import br.edu.ifg.luziania.pw.model.dto.CadastroDTO;
import br.edu.ifg.luziania.pw.model.dto.UsuarioLogadoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("cadastro")
public class CadastroController {
  @Inject UsuarioBO usuarioBO;

  @CheckedTemplate
  public static class Templates {
    public static native TemplateInstance cadastro();
    public static native TemplateInstance adminInicial();
  }

  @GET
  @Produces(MediaType.TEXT_HTML)
  public TemplateInstance cadastro() { return Templates.cadastro(); }

  @GET
  @Path("admin-inicial")
  @Produces(MediaType.TEXT_HTML)
  public TemplateInstance adminInicial() { return Templates.adminInicial(); }

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response cadastrar(CadastroDTO dto) {
    UsuarioLogadoDTO criado = usuarioBO.cadastrar(dto);
    return Response.status(Response.Status.CREATED).entity(criado).build();
  }

  @POST
  @Path("admin-inicial")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response cadastrarAdministradorInicial(CadastroAdminInicialDTO dto) {
    UsuarioLogadoDTO criado = usuarioBO.cadastrarAdministradorInicial(dto);
    return Response.status(Response.Status.CREATED).entity(criado).build();
  }
}
