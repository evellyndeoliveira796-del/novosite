package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.entity.Servico;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@ApplicationScoped
public class ServicoDAO {
  @PersistenceContext
  EntityManager em;

  public void salvar(Servico servico) { em.persist(servico); }
  public void atualizar(Servico servico) { em.merge(servico); }

  public void remover(Integer id) {
    Servico servico = buscarPorId(id);
    if (servico != null) em.remove(servico);
  }

  public Servico buscarPorId(Integer id) { return id == null ? null : em.find(Servico.class, id); }

  public List<Servico> listarTodos() {
    return em.createQuery("SELECT s FROM Servico s ORDER BY s.tipo, s.nome", Servico.class).getResultList();
  }

  public boolean possuiAgendamentos(Integer id) {
    return em.createQuery("SELECT COUNT(a) FROM Agendamento a WHERE a.servico.id = :id", Long.class)
      .setParameter("id", id)
      .getSingleResult() > 0;
  }
}
