package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@ApplicationScoped
public class UsuarioDAO {
  @PersistenceContext
  EntityManager em;

  public void salvar(Usuario usuario) { em.persist(usuario); }
  public void atualizar(Usuario usuario) { em.merge(usuario); }
  public Usuario buscarPorId(Integer id) { return id == null ? null : em.find(Usuario.class, id); }

  public Usuario buscarPorEmail(String email) {
    if (email == null) return null;
    try {
      return em.createQuery("SELECT u FROM Usuario u WHERE lower(u.email) = :email", Usuario.class)
        .setParameter("email", email.trim().toLowerCase())
        .getSingleResult();
    } catch (NoResultException e) {
      return null;
    }
  }

  public List<Usuario> listarTodos() {
    return em.createQuery("SELECT u FROM Usuario u ORDER BY u.nome", Usuario.class).getResultList();
  }

  public long contarAdministradores() {
    return em.createQuery("SELECT COUNT(u) FROM Usuario u WHERE u.perfil = 'ADMIN'", Long.class)
      .getSingleResult();
  }
}
