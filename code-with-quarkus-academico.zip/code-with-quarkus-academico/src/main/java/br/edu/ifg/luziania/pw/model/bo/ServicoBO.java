package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.ServicoDAO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import br.edu.ifg.luziania.pw.model.entity.Servico;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.BadRequestException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@ApplicationScoped
public class ServicoBO {
  @Inject ServicoDAO dao;
  @Inject UsuarioBO usuarioBO;
  @Inject AuditoriaBO auditoriaBO;

  @Transactional
  public ServicoDTO cadastrar(Integer executorId, ServicoDTO dto) {
    Usuario executor = usuarioBO.exigirAdmin(executorId);
    validar(dto);
    Servico servico = new Servico(dto.getNome().trim(), dto.getTipo().trim().toUpperCase(Locale.ROOT),
      dto.getDuracaoMinutos(), dto.getPreco());
    dao.salvar(servico);
    auditoriaBO.registrar("Serviço criado: " + servico.getNome() + " (#" + servico.getId() + ")", executor.getNome());
    return toDTO(servico);
  }

  @Transactional
  public ServicoDTO atualizar(Integer executorId, Integer id, ServicoDTO dto) {
    Usuario executor = usuarioBO.exigirAdmin(executorId);
    validar(dto);
    Servico servico = dao.buscarPorId(id);
    if (servico == null) throw new BadRequestException("Serviço não encontrado.");
    servico.setNome(dto.getNome().trim());
    servico.setTipo(dto.getTipo().trim().toUpperCase(Locale.ROOT));
    servico.setDuracaoMinutos(dto.getDuracaoMinutos());
    servico.setPreco(dto.getPreco());
    dao.atualizar(servico);
    auditoriaBO.registrar("Serviço atualizado: " + servico.getNome() + " (#" + id + ")", executor.getNome());
    return toDTO(servico);
  }

  @Transactional
  public void remover(Integer executorId, Integer id) {
    Usuario executor = usuarioBO.exigirAdmin(executorId);
    Servico servico = dao.buscarPorId(id);
    if (servico == null) throw new BadRequestException("Serviço não encontrado.");
    if (dao.possuiAgendamentos(id)) {
      throw new BadRequestException("Este serviço já possui agendamentos e não pode ser excluído.");
    }
    dao.remover(id);
    auditoriaBO.registrar("Serviço removido: " + servico.getNome() + " (#" + id + ")", executor.getNome());
  }

  public List<ServicoDTO> listarTodos() {
    return dao.listarTodos().stream().map(this::toDTO).collect(Collectors.toList());
  }

  private void validar(ServicoDTO dto) {
    if (dto == null || dto.getNome() == null || dto.getNome().isBlank()) {
      throw new BadRequestException("Nome do serviço é obrigatório.");
    }
    if (dto.getNome().trim().length() > 100) throw new BadRequestException("Nome deve ter até 100 caracteres.");
    String tipo = dto.getTipo() == null ? "" : dto.getTipo().trim().toUpperCase(Locale.ROOT);
    if (!"CORTE".equals(tipo) && !"BARBA".equals(tipo)) {
      throw new BadRequestException("Tipo deve ser CORTE ou BARBA.");
    }
    if (dto.getDuracaoMinutos() == null || dto.getDuracaoMinutos() <= 0) {
      throw new BadRequestException("Duração deve ser maior que zero.");
    }
    if (dto.getPreco() == null || dto.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
      throw new BadRequestException("Preço deve ser maior que zero.");
    }
  }

  private ServicoDTO toDTO(Servico s) {
    return new ServicoDTO(s.getId(), s.getNome(), s.getTipo(), s.getDuracaoMinutos(), s.getPreco());
  }
}
