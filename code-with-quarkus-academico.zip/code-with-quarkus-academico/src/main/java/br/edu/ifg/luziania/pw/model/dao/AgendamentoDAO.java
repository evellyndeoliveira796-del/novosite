package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.entity.Agendamento;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@ApplicationScoped
public class AgendamentoDAO {
  @PersistenceContext
  EntityManager em;

  public void salvar(Agendamento agendamento) { em.persist(agendamento); }
  public void atualizar(Agendamento agendamento) { em.merge(agendamento); }
  public Agendamento buscarPorId(Integer id) { return id == null ? null : em.find(Agendamento.class, id); }

  public List<Agendamento> listarTodos() {
    return em.createQuery("SELECT a FROM Agendamento a ORDER BY a.data, a.hora, a.id", Agendamento.class)
      .getResultList();
  }

  public List<Agendamento> listarDoCliente(Integer clienteId) {
    return em.createQuery("SELECT a FROM Agendamento a WHERE a.cliente.id = :clienteId ORDER BY a.data DESC, a.hora DESC", Agendamento.class)
      .setParameter("clienteId", clienteId)
      .getResultList();
  }

  public boolean existeConflito(LocalDate data, LocalTime hora) {
    Long total = em.createQuery(
        "SELECT COUNT(a) FROM Agendamento a WHERE a.data = :data AND a.hora = :hora AND a.status <> 'CANCELADO'",
        Long.class)
      .setParameter("data", data)
      .setParameter("hora", hora)
      .getSingleResult();
    return total > 0;
  }
}
