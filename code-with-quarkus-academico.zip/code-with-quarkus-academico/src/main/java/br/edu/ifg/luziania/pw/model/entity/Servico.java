package br.edu.ifg.luziania.pw.model.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "servico")
public class Servico {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(nullable = false, length = 100)
  private String nome;

  @Column(nullable = false, length = 20)
  private String tipo; // "CORTE" ou "BARBA"

  @Column(name = "duracao_minutos", nullable = false)
  private Integer duracaoMinutos;

  @Column(nullable = false)
  private BigDecimal preco;

  public Servico() {
  }

  public Servico(String nome, String tipo, Integer duracaoMinutos, BigDecimal preco) {
    this.nome = nome;
    this.tipo = tipo;
    this.duracaoMinutos = duracaoMinutos;
    this.preco = preco;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public Integer getDuracaoMinutos() {
    return duracaoMinutos;
  }

  public void setDuracaoMinutos(Integer duracaoMinutos) {
    this.duracaoMinutos = duracaoMinutos;
  }

  public BigDecimal getPreco() {
    return preco;
  }

  public void setPreco(BigDecimal preco) {
    this.preco = preco;
  }
}
