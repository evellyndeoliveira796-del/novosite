package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.UsuarioDAO;
import br.edu.ifg.luziania.pw.model.dto.AtualizarPerfilDTO;
import br.edu.ifg.luziania.pw.model.dto.CadastroAdminInicialDTO;
import br.edu.ifg.luziania.pw.model.dto.CadastroDTO;
import br.edu.ifg.luziania.pw.model.dto.UsuarioLogadoDTO;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.NotAuthorizedException;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@ApplicationScoped
public class UsuarioBO {
  private static final int ITERACOES = 160_000;
  private static final int TAMANHO_HASH = 256;

  @Inject UsuarioDAO dao;
  @Inject AuditoriaBO auditoriaBO;

  @ConfigProperty(name = "app.admin.bootstrap-token", defaultValue = "")
  String tokenAdminInicial;

  @Transactional
  public UsuarioLogadoDTO cadastrar(CadastroDTO dto) {
    Usuario novo = criarUsuario(dto, "CLIENTE");
    dao.salvar(novo);
    auditoriaBO.registrar("Cadastro de cliente: " + novo.getEmail(), novo.getNome());
    return toDTO(novo);
  }

  @Transactional
  public UsuarioLogadoDTO cadastrarAdministrador(CadastroDTO dto, Integer executorId) {
    Usuario executor = exigirAdmin(executorId);
    Usuario novo = criarUsuario(dto, "ADMIN");
    dao.salvar(novo);
    auditoriaBO.registrar("Cadastro de barbeiro/admin: " + novo.getEmail(), executor.getNome());
    return toDTO(novo);
  }

  @Transactional
  public UsuarioLogadoDTO cadastrarAdministradorInicial(CadastroAdminInicialDTO dto) {
    if (tokenAdminInicial == null || tokenAdminInicial.isBlank()) {
      throw new ForbiddenException("O cadastro inicial de administrador não foi habilitado no servidor.");
    }
    if (dto == null || dto.getTokenInicial() == null || !MessageDigest.isEqual(
        tokenAdminInicial.getBytes(StandardCharsets.UTF_8), dto.getTokenInicial().getBytes(StandardCharsets.UTF_8))) {
      throw new ForbiddenException("Token inicial inválido.");
    }
    if (dao.contarAdministradores() > 0) {
      throw new ForbiddenException("A configuração inicial já foi concluída. Peça a um administrador para criar novas contas.");
    }

    Usuario novo = criarUsuario(new CadastroDTO(dto.getNome(), dto.getEmail(), dto.getSenha()), "ADMIN");
    dao.salvar(novo);
    auditoriaBO.registrar("Criação do primeiro administrador: " + novo.getEmail(), "configuração inicial");
    return toDTO(novo);
  }

  @Transactional
  public UsuarioLogadoDTO autenticar(String email, String senha) {
    String emailNormalizado = normalizarEmail(email);
    Usuario usuario = dao.buscarPorEmail(emailNormalizado);
    if (usuario == null || senha == null || !senhaCorreta(senha, usuario.getSenha())) {
      throw new BadRequestException("E-mail ou senha inválidos.");
    }

    // Migra automaticamente senhas antigas em texto puro após um login válido.
    if (!usuario.getSenha().startsWith("pbkdf2$")) {
      usuario.setSenha(gerarHash(senha));
      dao.atualizar(usuario);
    }
    auditoriaBO.registrar("Login autenticado", usuario.getNome());
    return toDTO(usuario);
  }

  public UsuarioLogadoDTO obterPerfil(Integer usuarioId) {
    return toDTO(exigirUsuario(usuarioId));
  }

  @Transactional
  public UsuarioLogadoDTO atualizarPerfil(Integer usuarioId, AtualizarPerfilDTO dto) {
    Usuario usuario = exigirUsuario(usuarioId);
    if (dto == null || dto.getNome() == null || dto.getNome().isBlank()) {
      throw new BadRequestException("Nome é obrigatório.");
    }
    if (dto.getNome().trim().length() > 150) throw new BadRequestException("Nome deve ter até 150 caracteres.");
    if (dto.getEmail() == null || !dto.getEmail().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
      throw new BadRequestException("E-mail inválido.");
    }
    if (dto.getSenhaAtual() == null || !senhaCorreta(dto.getSenhaAtual(), usuario.getSenha())) {
      throw new ForbiddenException("Informe sua senha atual para confirmar as alterações.");
    }

    String email = normalizarEmail(dto.getEmail());
    if (email.length() > 150) throw new BadRequestException("E-mail deve ter até 150 caracteres.");
    Usuario comMesmoEmail = dao.buscarPorEmail(email);
    if (comMesmoEmail != null && !comMesmoEmail.getId().equals(usuario.getId())) {
      throw new BadRequestException("Já existe usuário com esse e-mail.");
    }

    usuario.setNome(dto.getNome().trim());
    usuario.setEmail(email);
    if (dto.getNovaSenha() != null && !dto.getNovaSenha().isBlank()) {
      if (dto.getNovaSenha().length() < 8) throw new BadRequestException("A nova senha deve ter ao menos 8 caracteres.");
      usuario.setSenha(gerarHash(dto.getNovaSenha()));
    }
    dao.atualizar(usuario);
    auditoriaBO.registrar("Atualização de perfil: " + usuario.getEmail(), usuario.getNome());
    return toDTO(usuario);
  }

  public List<UsuarioLogadoDTO> listarTodos(Integer executorId) {
    exigirAdmin(executorId);
    return dao.listarTodos().stream().map(this::toDTO).collect(Collectors.toList());
  }

  public Usuario exigirAdmin(Integer usuarioId) {
    Usuario usuario = exigirUsuario(usuarioId);
    if (!"ADMIN".equals(usuario.getPerfil())) throw new ForbiddenException("Acesso restrito ao administrador.");
    return usuario;
  }

  public Usuario exigirUsuario(Integer usuarioId) {
    Usuario usuario = dao.buscarPorId(usuarioId);
    if (usuario == null) throw new NotAuthorizedException("Sessão inválida. Faça login novamente.");
    return usuario;
  }

  private Usuario criarUsuario(CadastroDTO dto, String perfil) {
    if (dto == null || dto.getNome() == null || dto.getNome().isBlank()) {
      throw new BadRequestException("Nome é obrigatório.");
    }
    String nome = dto.getNome().trim();
    if (nome.length() > 150) throw new BadRequestException("Nome deve ter até 150 caracteres.");
    String email = normalizarEmail(dto.getEmail());
    if (email == null || !email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$") || email.length() > 150) {
      throw new BadRequestException("E-mail inválido.");
    }
    if (dto.getSenha() == null || dto.getSenha().length() < 8) {
      throw new BadRequestException("Senha deve ter ao menos 8 caracteres.");
    }
    if (dao.buscarPorEmail(email) != null) throw new BadRequestException("Já existe usuário com esse e-mail.");
    return new Usuario(nome, email, gerarHash(dto.getSenha()), perfil);
  }

  private String normalizarEmail(String email) {
    return email == null ? null : email.trim().toLowerCase(Locale.ROOT);
  }

  private String gerarHash(String senha) {
    byte[] salt = new byte[16];
    new SecureRandom().nextBytes(salt);
    byte[] hash = derivar(senha, salt, ITERACOES);
    return "pbkdf2$" + ITERACOES + "$" + Base64.getEncoder().encodeToString(salt) + "$"
      + Base64.getEncoder().encodeToString(hash);
  }

  private boolean senhaCorreta(String senha, String armazenada) {
    if (armazenada == null) return false;
    if (!armazenada.startsWith("pbkdf2$")) {
      return MessageDigest.isEqual(senha.getBytes(StandardCharsets.UTF_8), armazenada.getBytes(StandardCharsets.UTF_8));
    }
    try {
      String[] partes = armazenada.split("\\$", -1);
      if (partes.length != 4) return false;
      int iteracoes = Integer.parseInt(partes[1]);
      if (iteracoes < 10_000 || iteracoes > 1_000_000) return false;
      byte[] salt = Base64.getDecoder().decode(partes[2]);
      byte[] hashArmazenado = Base64.getDecoder().decode(partes[3]);
      return MessageDigest.isEqual(hashArmazenado, derivar(senha, salt, iteracoes));
    } catch (IllegalArgumentException e) {
      return false;
    }
  }

  private byte[] derivar(String senha, byte[] salt, int iteracoes) {
    PBEKeySpec spec = new PBEKeySpec(senha.toCharArray(), salt, iteracoes, TAMANHO_HASH);
    try {
      return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    } catch (Exception e) {
      throw new IllegalStateException("Não foi possível proteger a senha.", e);
    } finally {
      spec.clearPassword();
    }
  }

  private UsuarioLogadoDTO toDTO(Usuario usuario) {
    return new UsuarioLogadoDTO(usuario.getId(), usuario.getNome(), usuario.getEmail(), usuario.getPerfil());
  }
}
