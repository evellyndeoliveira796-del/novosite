package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.ServicoBO;
import br.edu.ifg.luziania.pw.model.bo.SessaoBO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("servico")
public class ServicoController {
  @Inject ServicoBO servicoBO;
  @Inject SessaoBO sessaoBO;

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public List<ServicoDTO> listar() { return servicoBO.listarTodos(); }

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response cadastrar(@HeaderParam("X-Usuario-Id") String usuarioId, ServicoDTO dto) {
    ServicoDTO criado = servicoBO.cadastrar(sessaoBO.exigirUsuarioId(usuarioId), dto);
    return Response.status(Response.Status.CREATED).entity(criado).build();
  }

  @PUT
  @Path("{id}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response atualizar(@HeaderParam("X-Usuario-Id") String usuarioId, @PathParam("id") Integer id, ServicoDTO dto) {
    return Response.ok(servicoBO.atualizar(sessaoBO.exigirUsuarioId(usuarioId), id, dto)).build();
  }

  @DELETE
  @Path("{id}")
  public Response remover(@HeaderParam("X-Usuario-Id") String usuarioId, @PathParam("id") Integer id) {
    servicoBO.remover(sessaoBO.exigirUsuarioId(usuarioId), id);
    return Response.noContent().build();
  }
}
