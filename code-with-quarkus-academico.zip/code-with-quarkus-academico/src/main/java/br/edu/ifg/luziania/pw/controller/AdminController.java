package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.bo.AuditoriaBO;
import br.edu.ifg.luziania.pw.model.bo.SessaoBO;
import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("admin")
public class AdminController {
  @Inject AgendamentoBO agendamentoBO;
  @Inject AuditoriaBO auditoriaBO;
  @Inject UsuarioBO usuarioBO;
  @Inject SessaoBO sessaoBO;

  @CheckedTemplate(requireTypeSafeExpressions = false)
  public static class Templates {
    public static native TemplateInstance admin();
  }

  @GET
  @Produces(MediaType.TEXT_HTML)
  public TemplateInstance admin(@HeaderParam("X-Usuario-Id") String usuarioId) {
    usuarioBO.exigirAdmin(sessaoBO.exigirUsuarioId(usuarioId));
    return Templates.admin();
  }

  @GET
  @Path("agendamentos")
  @Produces(MediaType.APPLICATION_JSON)
  public List<AgendamentoDTO> listarAgendamentos(@HeaderParam("X-Usuario-Id") String usuarioId) {
    return agendamentoBO.listarTodos(sessaoBO.exigirUsuarioId(usuarioId));
  }

  @PUT
  @Path("agendamentos/{id}/status")
  @Produces(MediaType.APPLICATION_JSON)
  public Response alterarStatus(@HeaderParam("X-Usuario-Id") String usuarioId,
                                @PathParam("id") Integer id,
                                @QueryParam("status") String status) {
    return Response.ok(agendamentoBO.alterarStatus(sessaoBO.exigirUsuarioId(usuarioId), id, status)).build();
  }

  @GET
  @Path("logs")
  @Produces(MediaType.APPLICATION_JSON)
  public List<LogAuditoriaDTO> listarLogs(@HeaderParam("X-Usuario-Id") String usuarioId) {
    return auditoriaBO.listarTodos(sessaoBO.exigirUsuarioId(usuarioId));
  }
}
