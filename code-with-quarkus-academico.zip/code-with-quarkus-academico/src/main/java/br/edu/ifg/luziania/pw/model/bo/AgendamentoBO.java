package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.AgendamentoDAO;
import br.edu.ifg.luziania.pw.model.dao.ServicoDAO;
import br.edu.ifg.luziania.pw.model.dao.UsuarioDAO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.dto.AgendarDTO;
import br.edu.ifg.luziania.pw.model.entity.Agendamento;
import br.edu.ifg.luziania.pw.model.entity.Servico;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.ForbiddenException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class AgendamentoBO {
  @Inject AgendamentoDAO dao;
  @Inject ServicoDAO servicoDAO;
  @Inject UsuarioDAO usuarioDAO;
  @Inject UsuarioBO usuarioBO;
  @Inject AuditoriaBO auditoriaBO;

  @Transactional
  public AgendamentoDTO cadastrar(Integer usuarioId, AgendarDTO dto) {
    Usuario cliente = usuarioBO.exigirUsuario(usuarioId);
    if (dto == null || dto.getData() == null || dto.getData().isBefore(LocalDate.now())) {
      throw new BadRequestException("Data do agendamento inválida.");
    }
    if (dto.getHora() == null || (dto.getData().equals(LocalDate.now()) && dto.getHora().isBefore(LocalTime.now()))) {
      throw new BadRequestException("Horário do agendamento inválido.");
    }
    if (dto.getServico() == null || dto.getServico().isBlank()) {
      throw new BadRequestException("Selecione um serviço.");
    }

    final Integer servicoId;
    try {
      servicoId = Integer.valueOf(dto.getServico());
    } catch (NumberFormatException e) {
      throw new BadRequestException("Serviço informado é inválido.");
    }
    Servico servico = servicoDAO.buscarPorId(servicoId);
    if (servico == null) throw new BadRequestException("Serviço informado não existe.");
    if (dao.existeConflito(dto.getData(), dto.getHora())) {
      throw new BadRequestException("Já existe um agendamento nesse horário.");
    }

    Agendamento agendamento = new Agendamento(cliente.getNome(), dto.getData(), dto.getHora(), servico, "PENDENTE");
    agendamento.setCliente(cliente);
    dao.salvar(agendamento);
    auditoriaBO.registrar("Novo agendamento #" + agendamento.getId() + " — " + servico.getNome()
      + " em " + dto.getData() + " às " + dto.getHora(), cliente.getNome());
    return toDTO(agendamento);
  }

  @Transactional
  public AgendamentoDTO alterarStatus(Integer executorId, Integer id, String novoStatus) {
    Usuario executor = usuarioBO.exigirAdmin(executorId);
    if (novoStatus == null || !List.of("PENDENTE", "CONFIRMADO", "CANCELADO").contains(novoStatus)) {
      throw new BadRequestException("Status inválido.");
    }
    Agendamento agendamento = dao.buscarPorId(id);
    if (agendamento == null) throw new BadRequestException("Agendamento não encontrado.");
    if ("CANCELADO".equals(agendamento.getStatus()) && !"CANCELADO".equals(novoStatus)) {
      throw new BadRequestException("Um agendamento cancelado não pode ser reaberto.");
    }
    String statusAnterior = agendamento.getStatus();
    agendamento.setStatus(novoStatus);
    dao.atualizar(agendamento);
    auditoriaBO.registrar("Agendamento #" + id + ": " + statusAnterior + " → " + novoStatus, executor.getNome());
    return toDTO(agendamento);
  }

  public List<AgendamentoDTO> listarTodos(Integer executorId) {
    usuarioBO.exigirAdmin(executorId);
    return dao.listarTodos().stream().map(this::toDTO).collect(Collectors.toList());
  }

  public List<AgendamentoDTO> listarDoCliente(Integer usuarioId) {
    usuarioBO.exigirUsuario(usuarioId);
    return dao.listarDoCliente(usuarioId).stream().map(this::toDTO).collect(Collectors.toList());
  }

  private AgendamentoDTO toDTO(Agendamento a) {
    Integer clienteId = a.getCliente() == null ? null : a.getCliente().getId();
    String nomeCliente = a.getCliente() == null ? a.getNomeCliente() : a.getCliente().getNome();
    return new AgendamentoDTO(a.getId(), clienteId, nomeCliente, a.getData(), a.getHora(),
      a.getServico().getNome(), a.getStatus());
  }
}
