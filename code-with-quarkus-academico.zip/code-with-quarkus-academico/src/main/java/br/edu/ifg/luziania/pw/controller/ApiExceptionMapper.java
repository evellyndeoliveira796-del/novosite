package br.edu.ifg.luziania.pw.controller;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.Map;

@Provider
public class ApiExceptionMapper implements ExceptionMapper<WebApplicationException> {
  @Override
  public Response toResponse(WebApplicationException exception) {
    int status = exception.getResponse() == null ? 500 : exception.getResponse().getStatus();
    String mensagem = exception.getMessage();
    if (mensagem == null || mensagem.isBlank()) mensagem = "Não foi possível concluir a solicitação.";
    return Response.status(status)
      .type(MediaType.APPLICATION_JSON_TYPE)
      .entity(Map.of("mensagem", mensagem))
      .build();
  }
}
