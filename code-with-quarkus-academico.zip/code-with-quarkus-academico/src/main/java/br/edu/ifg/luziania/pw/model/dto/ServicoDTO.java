package br.edu.ifg.luziania.pw.model.dto;

import java.math.BigDecimal;

public class ServicoDTO {

  private Integer id;
  private String nome;
  private String tipo;       // "CORTE" ou "BARBA"
  private Integer duracaoMinutos;
  private BigDecimal preco;

  // Construtor padrão
  public ServicoDTO() {
  }

  // Construtor completo
  public ServicoDTO(Integer id, String nome, String tipo, Integer duracaoMinutos, BigDecimal preco) {
    this.id = id;
    this.nome = nome;
    this.tipo = tipo;
    this.duracaoMinutos = duracaoMinutos;
    this.preco = preco;
  }

  // Getters e Setters
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public Integer getDuracaoMinutos() {
    return duracaoMinutos;
  }

  public void setDuracaoMinutos(Integer duracaoMinutos) {
    this.duracaoMinutos = duracaoMinutos;
  }

  public BigDecimal getPreco() {
    return preco;
  }

  public void setPreco(BigDecimal preco) {
    this.preco = preco;
  }
}
