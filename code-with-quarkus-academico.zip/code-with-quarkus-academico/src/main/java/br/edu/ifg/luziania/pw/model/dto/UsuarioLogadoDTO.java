package br.edu.ifg.luziania.pw.model.dto;

public class UsuarioLogadoDTO {

  private Integer id;
  private String nome;
  private String email;
  private String perfil; // "CLIENTE" ou "ADMIN"

  // Construtor padrão
  public UsuarioLogadoDTO() {
  }

  // Construtor completo
  public UsuarioLogadoDTO(Integer id, String nome, String email, String perfil) {
    this.id = id;
    this.nome = nome;
    this.email = email;
    this.perfil = perfil;
  }

  // Getters e Setters
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPerfil() {
    return perfil;
  }

  public void setPerfil(String perfil) {
    this.perfil = perfil;
  }
}
