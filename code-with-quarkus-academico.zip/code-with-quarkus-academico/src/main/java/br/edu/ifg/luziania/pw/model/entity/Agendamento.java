package br.edu.ifg.luziania.pw.model.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "agendamento")
public class Agendamento {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "nome_cliente", nullable = false, length = 150)
  private String nomeCliente;

  @Column(nullable = false)
  private LocalDate data;

  @Column(nullable = false)
  private LocalTime hora;

  @ManyToOne(optional = false)
  @JoinColumn(name = "servico_id")
  private Servico servico;

  @ManyToOne
  @JoinColumn(name = "cliente_id")
  private Usuario cliente;

  @Column(nullable = false, length = 20)
  private String status;

  public Agendamento() {}

  public Agendamento(String nomeCliente, LocalDate data, LocalTime hora, Servico servico, String status) {
    this.nomeCliente = nomeCliente;
    this.data = data;
    this.hora = hora;
    this.servico = servico;
    this.status = status;
  }

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public String getNomeCliente() { return nomeCliente; }
  public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
  public LocalDate getData() { return data; }
  public void setData(LocalDate data) { this.data = data; }
  public LocalTime getHora() { return hora; }
  public void setHora(LocalTime hora) { this.hora = hora; }
  public Servico getServico() { return servico; }
  public void setServico(Servico servico) { this.servico = servico; }
  public Usuario getCliente() { return cliente; }
  public void setCliente(Usuario cliente) { this.cliente = cliente; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
}
