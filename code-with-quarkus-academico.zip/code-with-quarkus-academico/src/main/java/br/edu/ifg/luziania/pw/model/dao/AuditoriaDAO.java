package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.entity.Auditoria;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@ApplicationScoped
public class AuditoriaDAO {

  @PersistenceContext
  EntityManager em;

  public void salvar(Auditoria log) {
    em.persist(log);
  }

  public List<Auditoria> listarTodos() {
    return em.createQuery(
        "SELECT l FROM Auditoria l ORDER BY l.dataHora DESC", Auditoria.class)
      .setMaxResults(500)
      .getResultList();
  }
}
