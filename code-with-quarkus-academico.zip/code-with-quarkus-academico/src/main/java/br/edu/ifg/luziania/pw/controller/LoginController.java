package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.SessaoBO;
import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.dto.LoginDTO;
import br.edu.ifg.luziania.pw.model.dto.UsuarioLogadoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Map;

@Path("login")
public class LoginController {
  @Inject UsuarioBO usuarioBO;
  @Inject SessaoBO sessaoBO;

  @CheckedTemplate
  public static class Templates {
    public static native TemplateInstance login();
  }

  @GET
  @Produces(MediaType.TEXT_HTML)
  public TemplateInstance login() { return Templates.login(); }

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response autenticar(LoginDTO dto) {
    UsuarioLogadoDTO usuario = usuarioBO.autenticar(
      dto == null ? null : dto.getEmail(), dto == null ? null : dto.getSenha());
    return Response.ok(usuario).build();
  }

  @GET
  @Path("sessao")
  @Produces(MediaType.APPLICATION_JSON)
  public UsuarioLogadoDTO sessao(@HeaderParam("X-Usuario-Id") String usuarioId) {
    return usuarioBO.obterPerfil(sessaoBO.exigirUsuarioId(usuarioId));
  }

  @POST
  @Path("logout")
  @Produces(MediaType.APPLICATION_JSON)
  public Response logout() { return Response.ok(Map.of("ok", true)).build(); }
}
