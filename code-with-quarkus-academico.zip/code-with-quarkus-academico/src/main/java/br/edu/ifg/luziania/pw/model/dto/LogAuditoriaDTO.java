package br.edu.ifg.luziania.pw.model.dto;

import java.time.LocalDateTime;

public class LogAuditoriaDTO {

  private Long id;
  private String acao;
  private String usuarioExecutor; // e-mail do usuário, ou "anônimo"
  private LocalDateTime dataHora;

  // Construtor padrão
  public LogAuditoriaDTO() {
  }

  // Construtor completo
  public LogAuditoriaDTO(Long id, String acao, String usuarioExecutor, LocalDateTime dataHora) {
    this.id = id;
    this.acao = acao;
    this.usuarioExecutor = usuarioExecutor;
    this.dataHora = dataHora;
  }

  // Getters e Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getAcao() {
    return acao;
  }

  public void setAcao(String acao) {
    this.acao = acao;
  }

  public String getUsuarioExecutor() {
    return usuarioExecutor;
  }

  public void setUsuarioExecutor(String usuarioExecutor) {
    this.usuarioExecutor = usuarioExecutor;
  }

  public LocalDateTime getDataHora() {
    return dataHora;
  }

  public void setDataHora(LocalDateTime dataHora) {
    this.dataHora = dataHora;
  }
}
