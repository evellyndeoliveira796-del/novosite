package br.edu.ifg.luziania.pw.model.dto;

public class CadastroAdminInicialDTO {
  private String nome;
  private String email;
  private String senha;
  private String tokenInicial;

  public CadastroAdminInicialDTO() {}

  public String getNome() { return nome; }
  public void setNome(String nome) { this.nome = nome; }
  public String getEmail() { return email; }
  public void setEmail(String email) { this.email = email; }
  public String getSenha() { return senha; }
  public void setSenha(String senha) { this.senha = senha; }
  public String getTokenInicial() { return tokenInicial; }
  public void setTokenInicial(String tokenInicial) { this.tokenInicial = tokenInicial; }
}
