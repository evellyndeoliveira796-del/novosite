package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.bo.SessaoBO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.dto.AgendarDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("agendar")
public class AgendarController {
  @Inject AgendamentoBO agendamentoBO;
  @Inject SessaoBO sessaoBO;

  @CheckedTemplate
  public static class Templates {
    public static native TemplateInstance agendar();
  }

  @GET
  @Produces(MediaType.TEXT_HTML)
  public TemplateInstance agendar() { return Templates.agendar(); }

  @POST
  @Path("agendamento")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response agendar(@HeaderParam("X-Usuario-Id") String usuarioId, AgendarDTO dto) {
    AgendamentoDTO criado = agendamentoBO.cadastrar(sessaoBO.exigirUsuarioId(usuarioId), dto);
    return Response.status(Response.Status.CREATED).entity(criado).build();
  }

  @GET
  @Path("meus")
  @Produces(MediaType.APPLICATION_JSON)
  public List<AgendamentoDTO> meusAgendamentos(@HeaderParam("X-Usuario-Id") String usuarioId) {
    return agendamentoBO.listarDoCliente(sessaoBO.exigirUsuarioId(usuarioId));
  }
}
