package br.edu.ifg.luziania.pw;

import br.edu.ifg.luziania.pw.model.bo.AuditoriaBO;
import br.edu.ifg.luziania.pw.model.bo.SessaoBO;
import br.edu.ifg.luziania.pw.model.dao.UsuarioDAO;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.ext.Provider;

@Provider
@Priority(Priorities.USER)
public class AuditoriaFilter implements ContainerRequestFilter {
  @Inject AuditoriaBO auditoriaBO;
  @Inject SessaoBO sessaoBO;
  @Inject UsuarioDAO usuarioDAO;

  @Override
  public void filter(ContainerRequestContext ctx) {
    String acao = ctx.getMethod() + " " + ctx.getUriInfo().getPath();
    Integer usuarioId = sessaoBO.usuarioIdOuNull(ctx.getHeaderString("X-Usuario-Id"));
    Usuario usuario = usuarioId == null ? null : usuarioDAO.buscarPorId(usuarioId);
    auditoriaBO.registrar(acao, usuario == null ? "anônimo" : usuario.getNome());
  }
}
