package br.edu.ifg.luziania.pw.model.bo;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotAuthorizedException;

/**
 * Contexto de usuário da versão acadêmica.
 * Nesta etapa, a identificação é enviada no header X-Usuario-Id.
 * Cookies assinados/sessões protegidas ficam reservados para o 4º bimestre.
 */
@ApplicationScoped
public class SessaoBO {
  public Integer exigirUsuarioId(String valor) {
    Integer id = usuarioIdOuNull(valor);
    if (id == null) throw new NotAuthorizedException("Faça login para continuar.");
    return id;
  }

  public Integer usuarioIdOuNull(String valor) {
    if (valor == null || valor.isBlank()) return null;
    try {
      int id = Integer.parseInt(valor.trim());
      return id > 0 ? id : null;
    } catch (NumberFormatException e) {
      return null;
    }
  }
}
