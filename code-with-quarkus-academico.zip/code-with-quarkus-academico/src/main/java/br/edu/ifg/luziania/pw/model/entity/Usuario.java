package br.edu.ifg.luziania.pw.model.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "usuario")
public class Usuario {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(nullable = false, length = 150)
  private String nome;

  @Column(nullable = false, unique = true, length = 150)
  private String email;

  @Column(nullable = false, length = 255)
  private String senha;

  @Column(nullable = false, length = 20)
  private String perfil;

  public Usuario() {}

  public Usuario(String nome, String email, String senha, String perfil) {
    this.nome = nome;
    this.email = email;
    this.senha = senha;
    this.perfil = perfil;
  }

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public String getNome() { return nome; }
  public void setNome(String nome) { this.nome = nome; }
  public String getEmail() { return email; }
  public void setEmail(String email) { this.email = email; }
  public String getSenha() { return senha; }
  public void setSenha(String senha) { this.senha = senha; }
  public String getPerfil() { return perfil; }
  public void setPerfil(String perfil) { this.perfil = perfil; }
}
