package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.AuditoriaDAO;
import br.edu.ifg.luziania.pw.model.dao.UsuarioDAO;
import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import br.edu.ifg.luziania.pw.model.entity.Auditoria;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class AuditoriaBO {
  @Inject AuditoriaDAO dao;
  @Inject UsuarioDAO usuarioDAO;

  @Transactional
  public void registrar(String acao, String usuarioExecutor) {
    String acaoSegura = acao == null ? "Ação não informada" : acao.trim();
    if (acaoSegura.length() > 255) acaoSegura = acaoSegura.substring(0, 255);
    String executor = (usuarioExecutor == null || usuarioExecutor.isBlank()) ? "anônimo" : usuarioExecutor.trim();
    if (executor.length() > 150) executor = executor.substring(0, 150);
    dao.salvar(new Auditoria(acaoSegura, executor));
  }

  public List<LogAuditoriaDTO> listarTodos(Integer executorId) {
    Usuario executor = usuarioDAO.buscarPorId(executorId);
    if (executor == null || !"ADMIN".equals(executor.getPerfil())) {
      throw new jakarta.ws.rs.ForbiddenException("Acesso restrito ao administrador.");
    }
    return dao.listarTodos().stream()
      .map(l -> new LogAuditoriaDTO(l.getId(), l.getAcao(), l.getUsuarioExecutor(), l.getDataHora()))
      .collect(Collectors.toList());
  }
}
