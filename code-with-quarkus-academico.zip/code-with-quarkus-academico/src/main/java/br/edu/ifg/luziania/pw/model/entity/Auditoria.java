package br.edu.ifg.luziania.pw.model.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "log_auditoria")
public class Auditoria {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, length = 255)
  private String acao;

  @Column(name = "usuario_executor", length = 150)
  private String usuarioExecutor;

  @Column(name = "data_hora", nullable = false)
  private LocalDateTime dataHora;

  public Auditoria() {
  }

  public Auditoria(String acao, String usuarioExecutor) {
    this.acao = acao;
    this.usuarioExecutor = usuarioExecutor;
    this.dataHora = LocalDateTime.now();
  }

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getAcao() { return acao; }
  public void setAcao(String acao) { this.acao = acao; }
  public String getUsuarioExecutor() { return usuarioExecutor; }
  public void setUsuarioExecutor(String usuarioExecutor) { this.usuarioExecutor = usuarioExecutor; }
  public LocalDateTime getDataHora() { return dataHora; }
  public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
}
