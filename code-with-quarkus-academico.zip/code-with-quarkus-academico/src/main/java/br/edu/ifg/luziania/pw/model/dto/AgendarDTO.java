package br.edu.ifg.luziania.pw.model.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class AgendarDTO {
  private LocalDate data;
  private LocalTime hora;
  private String servico;

  public AgendarDTO() {}

  public AgendarDTO(LocalDate data, LocalTime hora, String servico) {
    this.data = data;
    this.hora = hora;
    this.servico = servico;
  }

  public LocalDate getData() { return data; }
  public void setData(LocalDate data) { this.data = data; }
  public LocalTime getHora() { return hora; }
  public void setHora(LocalTime hora) { this.hora = hora; }
  public String getServico() { return servico; }
  public void setServico(String servico) { this.servico = servico; }
}
