package br.edu.ifg.luziania.pw.model.dto;

public class CadastroDTO {
  private String nome;
  private String email;
  private String senha;

  public CadastroDTO() {}

  public CadastroDTO(String nome, String email, String senha) {
    this.nome = nome;
    this.email = email;
    this.senha = senha;
  }

  public String getNome() { return nome; }
  public void setNome(String nome) { this.nome = nome; }
  public String getEmail() { return email; }
  public void setEmail(String email) { this.email = email; }
  public String getSenha() { return senha; }
  public void setSenha(String senha) { this.senha = senha; }
}
