package br.edu.ifg.luziania.pw.model.dto;

public class AtualizarPerfilDTO {
  private String nome;
  private String email;
  private String senhaAtual;
  private String novaSenha;

  public AtualizarPerfilDTO() {}

  public String getNome() { return nome; }
  public void setNome(String nome) { this.nome = nome; }
  public String getEmail() { return email; }
  public void setEmail(String email) { this.email = email; }
  public String getSenhaAtual() { return senhaAtual; }
  public void setSenhaAtual(String senhaAtual) { this.senhaAtual = senhaAtual; }
  public String getNovaSenha() { return novaSenha; }
  public void setNovaSenha(String novaSenha) { this.novaSenha = novaSenha; }
}
