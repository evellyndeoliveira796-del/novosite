package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.SessaoBO;
import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.dto.AtualizarPerfilDTO;
import br.edu.ifg.luziania.pw.model.dto.CadastroDTO;
import br.edu.ifg.luziania.pw.model.dto.UsuarioLogadoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("usuario")
public class UsuarioController {
  @Inject UsuarioBO usuarioBO;
  @Inject SessaoBO sessaoBO;

  @CheckedTemplate
  public static class Templates {
    public static native TemplateInstance usuario();
  }

  @GET
  @Produces(MediaType.TEXT_HTML)
  public TemplateInstance usuario() { return Templates.usuario(); }

  @GET
  @Path("me")
  @Produces(MediaType.APPLICATION_JSON)
  public UsuarioLogadoDTO meuPerfil(@HeaderParam("X-Usuario-Id") String usuarioId) {
    return usuarioBO.obterPerfil(sessaoBO.exigirUsuarioId(usuarioId));
  }

  @PUT
  @Path("me")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public UsuarioLogadoDTO atualizarMeuPerfil(@HeaderParam("X-Usuario-Id") String usuarioId, AtualizarPerfilDTO dto) {
    return usuarioBO.atualizarPerfil(sessaoBO.exigirUsuarioId(usuarioId), dto);
  }

  @GET
  @Path("lista")
  @Produces(MediaType.APPLICATION_JSON)
  public List<UsuarioLogadoDTO> listar(@HeaderParam("X-Usuario-Id") String usuarioId) {
    return usuarioBO.listarTodos(sessaoBO.exigirUsuarioId(usuarioId));
  }

  @POST
  @Path("administradores")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response cadastrarAdministrador(@HeaderParam("X-Usuario-Id") String usuarioId, CadastroDTO dto) {
    UsuarioLogadoDTO criado = usuarioBO.cadastrarAdministrador(dto, sessaoBO.exigirUsuarioId(usuarioId));
    return Response.status(Response.Status.CREATED).entity(criado).build();
  }
}
