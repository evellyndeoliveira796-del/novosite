package org.acme;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class CatalogoPageIT extends CatalogoPageTest {
    // Execute the same tests but in packaged mode.
}
