package org.acme;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;

@QuarkusTest
class FluxoUsuarioTest {
  @Test
  void cadastroPublicoNaoPodeCriarAdministradorEAgendamentoUsaNomeAutenticado() {
    String email = "cliente-" + UUID.randomUUID() + "@example.com";
    String senha = "senha-teste-123";
    String nome = "Cliente autenticado";

    given().contentType("application/json")
      .body(Map.of("nome", nome, "email", email, "senha", senha, "perfil", "ADMIN"))
      .when().post("/cadastro")
      .then().statusCode(201).body("perfil", equalTo("CLIENTE"));

    Integer usuarioId = given().contentType("application/json")
      .body(Map.of("email", email, "senha", senha))
      .when().post("/login")
      .then().statusCode(200).body("nome", equalTo(nome)).extract().path("id");

    given().header("X-Usuario-Id", usuarioId)
      .when().get("/login/sessao")
      .then().statusCode(200).body("email", equalTo(email));

    Integer serviceId = given().when().get("/servico")
      .then().statusCode(200).extract().jsonPath().getInt("[0].id");

    given().header("X-Usuario-Id", usuarioId).contentType("application/json")
      .body(Map.of("data", LocalDate.now().plusDays(1).toString(), "hora", "10:30",
        "servico", serviceId.toString(), "nome", "Nome adulterado pelo navegador"))
      .when().post("/agendar/agendamento")
      .then().statusCode(201).body("nomeCliente", equalTo(nome))
      .body("clienteId", org.hamcrest.Matchers.notNullValue());

    given().header("X-Usuario-Id", usuarioId).when().get("/agendar/meus")
      .then().statusCode(200).body("", hasSize(1));

    given().header("X-Usuario-Id", usuarioId).contentType("application/json")
      .body(Map.of("nome", "Cliente com perfil atualizado", "email", email,
        "senhaAtual", senha, "novaSenha", "senha-nova-789"))
      .when().put("/usuario/me")
      .then().statusCode(200).body("nome", equalTo("Cliente com perfil atualizado"));

    given().contentType("application/json").body(Map.of("email", email, "senha", senha))
      .when().post("/login").then().statusCode(400);
    given().contentType("application/json").body(Map.of("email", email, "senha", "senha-nova-789"))
      .when().post("/login").then().statusCode(200);

    given().header("X-Usuario-Id", usuarioId).when().get("/admin/agendamentos")
      .then().statusCode(403);
    given().header("X-Usuario-Id", usuarioId).contentType("application/json")
      .body(Map.of("nome", "Serviço proibido", "tipo", "CORTE", "duracaoMinutos", 20, "preco", 22.00))
      .when().post("/servico").then().statusCode(403);
  }

  @Test
  void primeiroAdminPodeGerenciarServicosEquipeAgendaEAuditoria() {
    String email = "admin-" + UUID.randomUUID() + "@example.com";
    String senha = "senha-admin-123";

    given().when().get("/cadastro/admin-inicial").then().statusCode(200);
    given().contentType("application/json")
      .body(Map.of("nome", "Barbeiro Principal", "email", email, "senha", senha,
        "tokenInicial", "teste-bootstrap-token-1"))
      .when().post("/cadastro/admin-inicial")
      .then().statusCode(201).body("perfil", equalTo("ADMIN"));

    Integer adminId = given().contentType("application/json")
      .body(Map.of("email", email, "senha", senha))
      .when().post("/login").then().statusCode(200).extract().path("id");

    given().header("X-Usuario-Id", adminId).when().get("/admin").then().statusCode(200);
    Integer serviceId = given().header("X-Usuario-Id", adminId).contentType("application/json")
      .body(Map.of("nome", "Serviço de teste", "tipo", "CORTE", "duracaoMinutos", 25, "preco", 29.90))
      .when().post("/servico").then().statusCode(201).extract().path("id");

    given().header("X-Usuario-Id", adminId).contentType("application/json")
      .body(Map.of("nome", "Serviço de teste atualizado", "tipo", "BARBA", "duracaoMinutos", 30, "preco", 35.00))
      .when().put("/servico/" + serviceId).then().statusCode(200)
      .body("nome", equalTo("Serviço de teste atualizado"));

    String clientEmail = "agenda-" + UUID.randomUUID() + "@example.com";
    given().contentType("application/json")
      .body(Map.of("nome", "Cliente da agenda", "email", clientEmail, "senha", "cliente-agenda-123"))
      .when().post("/cadastro").then().statusCode(201);
    Integer clientId = given().contentType("application/json")
      .body(Map.of("email", clientEmail, "senha", "cliente-agenda-123"))
      .when().post("/login").then().statusCode(200).extract().path("id");
    Integer appointmentId = given().header("X-Usuario-Id", clientId).contentType("application/json")
      .body(Map.of("data", LocalDate.now().plusDays(2).toString(), "hora", "11:15", "servico", serviceId.toString()))
      .when().post("/agendar/agendamento").then().statusCode(201).extract().path("id");

    given().header("X-Usuario-Id", adminId).when().get("/admin/agendamentos")
      .then().statusCode(200).body("id", org.hamcrest.Matchers.hasItem(appointmentId));
    given().header("X-Usuario-Id", adminId).when()
      .put("/admin/agendamentos/" + appointmentId + "/status?status=CONFIRMADO")
      .then().statusCode(200).body("status", equalTo("CONFIRMADO"));
    given().header("X-Usuario-Id", adminId).when().get("/usuario/lista").then().statusCode(200);
    given().header("X-Usuario-Id", adminId).when().get("/admin/logs").then().statusCode(200);

    given().header("X-Usuario-Id", adminId).contentType("application/json")
      .body(Map.of("nome", "Barbeiro da Equipe", "email", "equipe-" + UUID.randomUUID() + "@example.com", "senha", "senha-equipe-123"))
      .when().post("/usuario/administradores").then().statusCode(201).body("perfil", equalTo("ADMIN"));

    given().header("X-Usuario-Id", adminId).when().delete("/servico/" + serviceId).then().statusCode(400);
  }

  @Test
  void agendamentoExigeIdentificacaoAcademica() {
    given().contentType("application/json")
      .body(Map.of("data", LocalDate.now().plusDays(1).toString(), "hora", "10:00", "servico", "1"))
      .when().post("/agendar/agendamento").then().statusCode(401);
  }
}
