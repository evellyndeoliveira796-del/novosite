# Seu Jairo Barbearia — versão acadêmica até o 3º bimestre

Sistema web para a barbearia, desenvolvido com HTML, CSS, JavaScript, Java/Quarkus, REST, DTO, DAO, BO, Entity e banco de dados.

## Escopo desta versão

Esta versão contempla os requisitos dos 1º, 2º e 3º bimestres:

- front-end com HTML, CSS e JavaScript;
- login por e-mail e senha;
- cadastro e edição de usuário;
- perfis `CLIENTE` e `ADMIN`;
- agendamento usando o ID do usuário autenticado no fluxo da aplicação;
- painel do barbeiro com agenda;
- cadastro, edição e exclusão de serviços;
- catálogo carregado do banco de dados;
- regras de negócio nos BOs;
- acesso ao banco pelos DAOs;
- entidades JPA;
- DTOs entre front-end e back-end;
- endpoints REST;
- auditoria das ações.

## O que não está nesta versão

Cookies assinados, cookies `HttpOnly`, tokens HMAC e proteção de sessão foram retirados propositalmente. Eles ficam para o 4º bimestre, conforme solicitado.

Para manter o fluxo de autenticação didático, depois do login o JavaScript guarda o ID do usuário em `sessionStorage` e envia o header:

```text
X-Usuario-Id: 12
```

**Atenção:** esse mecanismo é somente acadêmico e não deve ser usado como segurança em produção, pois o usuário pode alterar o valor no navegador.

## Configuração

```bash
export DATABASE_URL='jdbc:postgresql://localhost:5432/barbearia'
export DATABASE_USERNAME='postgres'
export DATABASE_PASSWORD='senha-local'
export APP_ADMIN_BOOTSTRAP_TOKEN="token-temporario"
./mvnw quarkus:dev
```

O primeiro administrador é criado em `/cadastro/admin-inicial`. Depois, remova o token:

```bash
unset APP_ADMIN_BOOTSTRAP_TOKEN
```

## Testes

```bash
./mvnw clean verify
```

Os testes usam H2 em memória e validam cadastro, login sem cookie, identificação por header, agendamento, perfil, permissões administrativas, CRUD de serviços, equipe e auditoria.
